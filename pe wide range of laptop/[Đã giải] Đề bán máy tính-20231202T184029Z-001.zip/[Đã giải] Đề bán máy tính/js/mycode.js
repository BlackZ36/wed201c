function openNav() {
  // var mySidenav = document.getElementById("mySidenav");
  // mySidenav.style.display = "block";
  // // console.log(1);
  document.getElementById("mySidenav").style.display = "block";
  document.getElementById("mySidenav").style.width="250px";
}
function closeNav(){
    document.getElementById("mySidenav").style.width="0";
}
